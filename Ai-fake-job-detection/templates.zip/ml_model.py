"""
Machine Learning Module for Fake Job Post Detection
Advanced ML Algorithm for Online Recruitment Scam Detection
"""

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier


class FakeJobPostDetector:
    """
    Machine Learning model for detecting fake job postings
    Uses RandomForest Classifier with TF-IDF vectorization
    """
    
    def __init__(self):
        """Initialize the ML model with training data"""
        self.model = None
        self.vectorizer = None
        self._train_model()
    
    def _train_model(self):
        """Train the ML model on fake vs legitimate job post data"""
        # Training data with fake job post indicators
        training_texts = [
            "Send money to apply",
            "Work from home easy money",
            "No experience needed high pay",
            "Click here to register",
            "Urgent hiring immediate",
            "Free training provided jobs",
            "Make money fast online",
            "Investment required employment",
            "Guaranteed income opportunity",
            "Limited time offer job",
            # Legitimate posts
            "Software Engineer Full Stack Developer Position",
            "We are hiring experienced Python developers for our team",
            "Marketing Manager position at growing tech company",
            "Data Scientist role with competitive salary",
            "Customer Service Representative opportunity",
            "Project Manager needed for enterprise clients",
            "Business Development Executive opening",
            "Quality Assurance Engineer required"
        ]
        
        # Labels: 1 = Fake/Scam, 0 = Legitimate
        labels = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0]
        
        # Create TF-IDF vectorizer
        self.vectorizer = TfidfVectorizer(
            max_features=100,
            stop_words='english',
            lowercase=True,
            ngram_range=(1, 2)
        )
        
        # Transform training texts
        X = self.vectorizer.fit_transform(training_texts)
        
        # Create and train RandomForest classifier
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            min_samples_split=2,
            random_state=42,
            n_jobs=-1
        )
        
        self.model.fit(X, labels)
    
    def predict(self, job_description, job_title, company_name, salary):
        """
        Predict if a job post is fake or legitimate
        
        Args:
            job_description (str): The job post description
            job_title (str): Job position title
            company_name (str): Company name from the posting
            salary (str): Salary information
        
        Returns:
            dict: Prediction results with confidence scores
        """
        try:
            # Combine all text features
            combined_text = f"{job_title} {company_name} {job_description} {salary}"
            
            # Validate input
            if not combined_text.strip():
                return {
                    'error': 'Job post content is empty',
                    'is_fake': None,
                    'confidence': 0,
                    'fake_probability': 0,
                    'legitimate_probability': 0
                }
            
            # Vectorize the input
            X = self.vectorizer.transform([combined_text])
            
            # Make prediction
            prediction = self.model.predict(X)[0]
            probabilities = self.model.predict_proba(X)[0]
            
            # Calculate confidence (highest probability)
            confidence = max(probabilities) * 100
            
            # Get individual probabilities
            legitimate_prob = probabilities[0] * 100  # Class 0: Legitimate
            fake_prob = probabilities[1] * 100        # Class 1: Fake/Scam
            
            return {
                'is_fake': prediction == 1,
                'confidence': confidence,
                'fake_probability': fake_prob,
                'legitimate_probability': legitimate_prob,
                'prediction_label': 'LIKELY SCAM' if prediction == 1 else 'APPEARS LEGITIMATE'
            }
        
        except Exception as e:
            return {
                'error': str(e),
                'is_fake': None,
                'confidence': 0,
                'fake_probability': 0,
                'legitimate_probability': 0
            }
    
    def get_model_info(self):
        """Get information about the ML model"""
        return {
            'model_type': 'RandomForest Classifier',
            'vectorizer_type': 'TF-IDF',
            'features': 100,
            'estimators': 100,
            'training_samples': 18,
            'fake_samples': 10,
            'legitimate_samples': 8
        }


# Initialize the detector
detector = FakeJobPostDetector()


def process_job_post(job_description, job_title, company_name, salary=""):
    """
    Process a job post and return prediction results
    
    Args:
        job_description (str): The job description text
        job_title (str): Job title
        company_name (str): Company name
        salary (str): Salary information
    
    Returns:
        dict: Prediction results from the ML model
    """
    result = detector.predict(job_description, job_title, company_name, salary)
    return result


def get_detector_info():
    """Get information about the detector model"""
    return detector.get_model_info()
